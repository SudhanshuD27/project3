﻿namespace Hrms_final_draft.Models
{
    public class ResignationLetter
    {
        public string EmployeeName { get; set; }
        public string EmployeeEmail { get; set; }
        public string DepartmentHeadName { get; set; }
        public DateTime ResignationDate { get; set; }
        public DateTime LastDate { get; set; }
    }
}
