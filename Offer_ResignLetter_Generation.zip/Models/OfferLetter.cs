﻿namespace Hrms_final_draft.Models
{
    public class OfferLetter
    {
        public string EmployeeName { get; set; }
        public string EmployeeEmail { get; set; }
        public string Address { get; set; }
        public string Position { get; set; }
        public DateTime StartDate { get; set; }
        public string Salary { get; set; }
        public DateTime AcceptanceDeadline { get; set; }

        public int OrganizationId { get; set; }

        public string OrganizationLogo { get; set; }


    }
}