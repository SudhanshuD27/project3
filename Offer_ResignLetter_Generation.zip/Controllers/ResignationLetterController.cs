﻿using Microsoft.AspNetCore.Mvc;
using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using System.Net.Mail;
using System.Net;
using SelectPdf;
using System.IO;

namespace Hrms_final_draft.Controllers
{
    public class ResignationLetterController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;

        public ResignationLetterController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        // STEP 1: Template Selection
        public IActionResult SelectTemplate()
        {
            return View();
        }

        // STEP 2: Customize Form
        public IActionResult Customize(string templateName)
        {
            ViewBag.TemplateName = templateName;
            return View();
        }

        // STEP 3: Form Submission
        [HttpPost]
        public IActionResult Customize(ResignationLetter model, string templateName)
        {
            string html = templateName switch
            {
                "templet1" => GenerateTemplate1(model),
                "templet2" => GenerateTemplate2(model),
                "templet3" => GenerateTemplate3(model),
                _ => "Invalid template"
            };

            var pdfPath = ConvertHtmlToPdf(html, model.EmployeeEmail);
            SendEmailWithAttachment(pdfPath, model.EmployeeEmail);
            SaveDataIntoDb(model.EmployeeEmail, "Resignation-letter", Path.GetFileName(pdfPath));

            TempData["success"] = "Resignation letter generated and emailed successfully!";
            return RedirectToAction("SelectTemplate");
        }

        private string GenerateTemplate1(ResignationLetter rl)
        {
            return $@"
            <html>
            <body style='font-family:Arial; padding:30px;'>
                <h2 style='color:#c0392b;'>Resignation Letter</h2>
                <p>Date: <b>{DateTime.Now:dd-MM-yyyy}</b></p>
                <p>To,<br><b>{rl.DepartmentHeadName}</b></p>
                <p>I, <b>{rl.EmployeeName}</b>, hereby resign from my position. My last working day will be <b>{rl.LastDate:dd-MM-yyyy}</b>.</p>
                <p>Resignation submitted on: <b>{rl.ResignationDate:dd-MM-yyyy}</b>.</p>
                <p>Thank you for the support and opportunities.</p>
                <br><br>
                <p>Regards,<br>{rl.EmployeeName}</p>
            </body>
            </html>";
        }

        private string GenerateTemplate2(ResignationLetter rl)
        {
            return $@"
            <html>
            <body style='font-family:Segoe UI; background:#f9f9f9; padding:30px;'>
                <h2 style='color:#2c3e50;'>Formal Resignation</h2>
                <p><b>Date:</b> {DateTime.Now:dd-MM-yyyy}</p>
                <p>To: <b>{rl.DepartmentHeadName}</b></p>
                <p>This is to inform that I, <b>{rl.EmployeeName}</b>, am resigning from my role effective <b>{rl.LastDate:dd-MM-yyyy}</b>.</p>
                <p>Submitted on: <b>{rl.ResignationDate:dd-MM-yyyy}</b>.</p>
                <p>Thank you.</p>
                <br>
                <p><b>{rl.EmployeeName}</b></p>
            </body>
            </html>";
        }

        private string GenerateTemplate3(ResignationLetter rl)
        {
            return $@"
            <html>
            <body style='font-family:Verdana; padding:30px;'>
                <h2 style='color:#27ae60;'>Notice of Resignation</h2>
                <p>Date: {DateTime.Now:dd-MM-yyyy}</p>
                <p>Dear <b>{rl.DepartmentHeadName}</b>,</p>
                <p>Please accept this letter as formal notice of my resignation. I am <b>{rl.EmployeeName}</b> and my last working day will be <b>{rl.LastDate:dd-MM-yyyy}</b>.</p>
                <p>Submitted on: {rl.ResignationDate:dd-MM-yyyy}</p>
                <p>I appreciate the opportunities offered to me during my time here.</p>
                <br>
                <p>Sincerely,<br>{rl.EmployeeName}</p>
            </body>
            </html>";
        }

        private string ConvertHtmlToPdf(string htmlContent, string email)
        {
            var pdfGenerator = new HtmlToPdf();
            var doc = pdfGenerator.ConvertHtmlString(htmlContent);
            var pdfBytes = doc.Save();
            doc.Close();

            string folderPath = Path.Combine(env.WebRootPath, "Content", "resignation-letters");
            Directory.CreateDirectory(folderPath);

            string fileName = $"Resignation-letter{new Random().Next(100000, 99999999)}.pdf";
            string filePath = Path.Combine(folderPath, fileName);
            System.IO.File.WriteAllBytes(filePath, pdfBytes);

            return filePath;
        }

        private void SendEmailWithAttachment(string filePath, string toEmail)
        {
            try
            {
                var mail = new MailMessage();
                mail.From = new MailAddress("sudhanshu.u.deshmukh@gmail.com");
                mail.To.Add(toEmail);
                mail.Subject = "Resignation Letter";
                mail.Body = "Please find your resignation letter attached.";
                mail.Attachments.Add(new Attachment(filePath));

                var smtp = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("sudhanshu.u.deshmukh@gmail.com", "fqogwdunkppmcehs"),
                    EnableSsl = true
                };

                smtp.Send(mail);
            }
            catch (Exception ex)
            {
                TempData["error"] = "Email failed: " + ex.Message;
            }
        }

        private void SaveDataIntoDb(string email, string docName, string docFile)
        {
            var record = new AdminDocuments
            {
                Email = email,
                DocName = docName,
                DocFile = docFile
            };

            db.AdminDocuments.Add(record);
            db.SaveChanges();
        }
    }
}
