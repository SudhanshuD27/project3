﻿using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class OrganizationController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;

        public OrganizationController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        [HttpGet]
        public IActionResult AddOrganization()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddOrganization(Organization org, IFormFile logoFile)
        {
            if (logoFile != null && logoFile.Length > 0)
            {
                string uploadsFolder = Path.Combine(env.WebRootPath, "company-logos");
                Directory.CreateDirectory(uploadsFolder); // Ensure folder exists

                string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(logoFile.FileName);
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    logoFile.CopyTo(stream);
                }

                org.OrganizationLogo = "/company-logos/" + uniqueFileName;
            }

            db.Organization.Add(org);
            db.SaveChanges();

            ViewBag.Message = "Company details added successfully!";
            ModelState.Clear(); // Reset the form

            return View(); // Return the same view with empty model
        }
    }
}
