﻿using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class ViewDocumentsController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;

        public ViewDocumentsController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        public IActionResult Index()
        {
            var documents = db.AdminDocuments.ToList();
            return View(documents);
        }

        public IActionResult ViewPdf(int id)
        {
            var doc = db.AdminDocuments.Find(id);
            if (doc == null) return NotFound();

            string folder = doc.DocName == "Resignation-letter" ? "resignation-letters" : "offer-letters";
            string path = Path.Combine(env.WebRootPath, "Content", folder, doc.DocFile);
            if (!System.IO.File.Exists(path)) return NotFound();

            byte[] fileBytes = System.IO.File.ReadAllBytes(path);
            return File(fileBytes, "application/pdf");
        }

        public IActionResult DownloadPdf(int id)
        {
            var doc = db.AdminDocuments.Find(id);
            if (doc == null) return NotFound();

            string folder = doc.DocName == "Resignation-letter" ? "resignation-letters" : "offer-letters";
            string path = Path.Combine(env.WebRootPath, "Content", folder, doc.DocFile);
            if (!System.IO.File.Exists(path)) return NotFound();

            byte[] fileBytes = System.IO.File.ReadAllBytes(path);
            return File(fileBytes, "application/pdf", doc.DocFile);
        }
    }
}
