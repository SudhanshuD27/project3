﻿using Microsoft.AspNetCore.Mvc;
using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using System.Net.Mail;
using System.Net;
using SelectPdf;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Hrms_final_draft.Controllers
{
    public class OfferLetterController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;

        public OfferLetterController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        // STEP 1: Show template cards
        public IActionResult SelectTemplate()
        {
            return View();
        }

        // STEP 2: Show customize form with selected template
        public IActionResult Customize(string templateName)
        {
            ViewBag.TemplateName = templateName;

            ViewBag.OrganizationNames = db.Organization
                .Select(o => new SelectListItem
                {
                    Value = o.OrganizationId.ToString(),
                    Text = o.OrganizationName
                })
                .ToList();

            ViewBag.OrganizationLogos = db.Organization
                .Select(o => new SelectListItem
                {
                    Value = o.OrganizationLogo,
                    Text = o.OrganizationName + " (" + Path.GetFileName(o.OrganizationLogo) + ")"
                })
                .ToList();

            return View();
        }

        // STEP 3: Handle form submission
        [HttpPost]
        public IActionResult Customize(OfferLetter model, string templateName, int organizationId)
        {
            var org = db.Organization.FirstOrDefault(o => o.OrganizationId == organizationId);
            if (org == null)
            {
                TempData["error"] = "Invalid organization selected.";
                return RedirectToAction("Customize", new { templateName });
            }

            string html = templateName switch
            {
                "templet1" => GenerateTemplate1(org, model),
                "templet2" => GenerateTemplate2(org, model),
                "templet3" => GenerateTemplate3(org, model),
                _ => "Invalid template"
            };

            var pdfFilePath = ConvertHtmlToPdf(html, model.EmployeeEmail);
            SendEmailWithAttachment(pdfFilePath, model.EmployeeEmail);
            SaveDataIntoDb(model.EmployeeEmail, "Offer-letter", Path.GetFileName(pdfFilePath));

            TempData["success"] = "Offer letter generated, emailed, and saved successfully!";
            return RedirectToAction("SelectTemplate");
        }

        private string GenerateTemplate1(Organization org, OfferLetter ol)
        {
            return $@"
            <html>
            <body style='font-family:Arial; padding:30px;'>
                <img src='{org.OrganizationLogo}' style='width:150px;' />
                <h2 style='color:#004a99;'>Offer of Employment</h2>
                <p>Date: <b>{DateTime.Now:dd-MM-yyyy}</b></p>
                <p>Dear <b>{ol.EmployeeName}</b>,</p>
                <p>We are pleased to offer you the position of <b>{ol.Position}</b> at <b>{org.OrganizationName}</b>.</p>
                <p><b>Start Date:</b> {ol.StartDate:dd-MM-yyyy}</p>
                <p><b>Salary:</b> {ol.Salary}</p>
                <p><b>Location:</b> {org.OrganizationAddress}</p>
                <p>Please confirm your acceptance by <b>{ol.AcceptanceDeadline:dd-MM-yyyy}</b>.</p>
                <br/><br/>
                <p>Best regards,</p>
                <p>{org.OrganizationName}</p>
            </body>
            </html>";
        }

        private string GenerateTemplate2(Organization org, OfferLetter ol)
        {
            return $@"
            <html>
            <body style='font-family:Segoe UI; background:#f9f9f9; padding:30px;'>
                <h2 style='color:#2a5298;'>Exciting Opportunity</h2>
                <p>Hello <b>{ol.EmployeeName}</b>,</p>
                <p>You're selected as <b>{ol.Position}</b> at <b>{org.OrganizationName}</b>.</p>
                <ul>
                    <li><b>Start:</b> {ol.StartDate:dd-MM-yyyy}</li>
                    <li><b>Salary:</b> {ol.Salary}</li>
                    <li><b>Address:</b> {org.OrganizationAddress}</li>
                </ul>
                <p>Please confirm by <b>{ol.AcceptanceDeadline:dd-MM-yyyy}</b>.</p>
            </body>
            </html>";
        }

        private string GenerateTemplate3(Organization org, OfferLetter ol)
        {
            return $@"
            <html>
            <body style='font-family:Verdana; padding:25px;'>
                <h2 style='color:#3c9e74;'>Welcome Aboard</h2>
                <p>Hi <b>{ol.EmployeeName}</b>,</p>
                <p>We’re excited to have you join us at <b>{org.OrganizationName}</b> as a <b>{ol.Position}</b>.</p>
                <p>Start: {ol.StartDate:dd-MM-yyyy} | Salary: {ol.Salary}</p>
                <p>Location: {org.OrganizationAddress}</p>
                <p>Please accept by <b>{ol.AcceptanceDeadline:dd-MM-yyyy}</b>.</p>
                <p>Cheers,<br/>{org.OrganizationName}</p>
            </body>
            </html>";
        }

        private string ConvertHtmlToPdf(string htmlContent, string email)
        {
            var pdfGenerator = new HtmlToPdf();
            var doc = pdfGenerator.ConvertHtmlString(htmlContent);
            var pdfBytes = doc.Save();
            doc.Close();

            string folderPath = Path.Combine(env.WebRootPath, "Content", "offer-letters");
            Directory.CreateDirectory(folderPath);

            string fileName = $"Offer-letter{new Random().Next(100000, 99999999)}.pdf";
            string filePath = Path.Combine(folderPath, fileName);
            System.IO.File.WriteAllBytes(filePath, pdfBytes);

            return filePath;
        }

        private void SendEmailWithAttachment(string filePath, string toEmail)
        {
            try
            {
                var mail = new MailMessage();
                mail.From = new MailAddress("sudhanshu.u.deshmukh@gmail.com");
                mail.To.Add(toEmail);
                mail.Subject = "Offer Letter";
                mail.Body = "Please find your offer letter attached.";
                mail.Attachments.Add(new Attachment(filePath));

                var smtp = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    Credentials = new NetworkCredential("sudhanshu.u.deshmukh@gmail.com", "fqogwdunkppmcehs"),
                    EnableSsl = true
                };

                smtp.Send(mail);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Email failed: " + ex.Message);
            }
        }

        private void SaveDataIntoDb(string email, string docName, string docFile)
        {
            var record = new AdminDocuments
            {
                Email = email,
                DocName = docName,
                DocFile = docFile
            };

            db.AdminDocuments.Add(record);
            db.SaveChanges();
        }
    }
}
