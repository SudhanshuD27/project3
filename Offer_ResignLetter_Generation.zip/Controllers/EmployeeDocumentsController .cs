﻿using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class EmployeeDocumentsController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment _env;

        public EmployeeDocumentsController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this._env = env;
        }

        // ✅ Show user's documents
        public IActionResult MyDocuments()
        {
            var email = HttpContext.Session.GetString("UserEmail");
            if (string.IsNullOrEmpty(email))
            {
                TempData["error"] = "Please login first.";
                return RedirectToAction("Index", "Login");
            }

            var docs = db.AdminDocuments
                         .Where(d => d.Email == email)
                         .OrderByDescending(d => d.AdminDocId)
                         .ToList();

            return View(docs);
        }

        // ✅ View PDF inline in browser
        public IActionResult ViewPdf(int id)
        {
            var doc = db.AdminDocuments.FirstOrDefault(d => d.AdminDocId == id);
            if (doc == null) return NotFound();

            var email = HttpContext.Session.GetString("UserEmail");
            if (doc.Email != email) return Unauthorized();

            string folder = doc.DocName == "Offer-letter" ? "offer-letters" : "resignation-letters";
            string path = Path.Combine(_env.WebRootPath, "Content", folder, doc.DocFile);

            if (!System.IO.File.Exists(path)) return NotFound();

            return PhysicalFile(path, "application/pdf");
        }

        // ✅ Download PDF as attachment
        public IActionResult DownloadPdf(int id)
        {
            var doc = db.AdminDocuments.FirstOrDefault(d => d.AdminDocId == id);
            if (doc == null) return NotFound();

            var email = HttpContext.Session.GetString("UserEmail");
            if (doc.Email != email) return Unauthorized();

            string folder = doc.DocName == "Offer-letter" ? "offer-letters" : "resignation-letters";
            string path = Path.Combine(_env.WebRootPath, "Content", folder, doc.DocFile);

            if (!System.IO.File.Exists(path)) return NotFound();

            return PhysicalFile(path, "application/pdf", doc.DocFile); // attachment mode
        }
    }
}
