﻿using Hrms_final_draft.Data;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class ViewDocumentsController : Controller
    {
        private readonly ApplicationDbContext db;

        public ViewDocumentsController(ApplicationDbContext db)
        {
            this.db = db;
        }

        // For Employee - shows only their documents
        public IActionResult Index()
        {
            var email = User.Identity.Name;
            var data = db.AdminDocuments.Where(x => x.Email == email).ToList();
            return View(data);
        }

        // For Admin - shows all documents
        public IActionResult IndexAtAdmin()
        {
            var data = db.AdminDocuments.ToList();
            return View(data);
        }

        // View PDF in browser
        public IActionResult ViewPdf(int id)
        {
            var doc = db.AdminDocuments.FirstOrDefault(x => x.AdminDocId == id);
            if (doc == null || string.IsNullOrEmpty(doc.DocFile))
                return NotFound();

            string folder = doc.DocName == "Offer-letter" ? "offer-letters" :
                            doc.DocName == "Resignation-letter" ? "resignation-letters" : null;

            if (folder == null)
                return NotFound();

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Content", folder, doc.DocFile);
            if (!System.IO.File.Exists(filePath))
                return NotFound();

            return File(System.IO.File.OpenRead(filePath), "application/pdf");
        }

        // Download PDF
        public IActionResult DownloadPDF(int id)
        {
            var doc = db.AdminDocuments.FirstOrDefault(x => x.AdminDocId == id);
            if (doc == null || string.IsNullOrEmpty(doc.DocFile))
                return NotFound();

            string folder = doc.DocName == "Offer-letter" ? "offer-letters" :
                            doc.DocName == "Resignation-letter" ? "resignation-letters" : null;

            if (folder == null)
                return NotFound();

            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Content", folder, doc.DocFile);
            if (!System.IO.File.Exists(filePath))
                return NotFound();

            return File(System.IO.File.OpenRead(filePath), "application/pdf", Path.GetFileName(filePath));
        }
    }
}
