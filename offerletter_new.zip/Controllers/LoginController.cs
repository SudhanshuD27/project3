﻿using Hrms_final_draft.Data;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class LoginController : Controller
    {
        ApplicationDbContext db;
        public LoginController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string email, string password)
        {
            var user = db.User.FirstOrDefault(u =>
                u.Email == email &&
                (u.PasswordHash ?? "") == password &&
                (u.Status ?? "") == "Active");

            if (user != null)
            {
                HttpContext.Session.SetInt32("UserId", user.UserId);
                HttpContext.Session.SetString("UserEmail", user.Email);
                string role = (user.RoleId == 3) ? "Admin" : "User";
                HttpContext.Session.SetString("UserRole", role);

                if (role == "Admin")
                    return RedirectToAction("AdminDashboard");
                else
                    return RedirectToAction("UserDashboard");
            }

            ViewBag.Msg = "Invalid email or password";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        public IActionResult AdminDashboard()
        {
            return View();
        }

        public IActionResult UserDashboard()
        {
            return View();
        }
    }
}