﻿using Hrms_final_draft.Data;
using Hrms_final_draft.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hrms_final_draft.Controllers
{
    public class OrganizationController : Controller
    {
        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment env;

        public OrganizationController(ApplicationDbContext db, IWebHostEnvironment env)
        {
            this.db = db;
            this.env = env;
        }

        public IActionResult Index()
        {
            var orgs = db.Organization.ToList();
            return View(orgs);
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(Organization org, IFormFile logo)
        {
            if (ModelState.IsValid && logo != null)
            {
                string folder = "/Uploads/logos/";
                string path = folder + Guid.NewGuid().ToString() + Path.GetExtension(logo.FileName);
                string fullPath = Path.Combine(env.WebRootPath + folder.TrimStart('/'), Path.GetFileName(path));

                Directory.CreateDirectory(Path.GetDirectoryName(fullPath));

                using (var fs = new FileStream(fullPath, FileMode.Create))
                {
                    await logo.CopyToAsync(fs);
                }

                org.OrganizationLogo = path;
                db.Organization.Add(org);
                db.SaveChanges();
                TempData["success"] = "Company added successfully";
                return RedirectToAction("Index");
            }

            TempData["error"] = "Please fill all required fields and upload a logo.";
            return View(org);
        }
    }
}
