using Microsoft.AspNetCore.Mvc;


namespace Hrms_final_draft.Controllers
{
    public class HomeController : Controller
    { 
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }
    }
}
