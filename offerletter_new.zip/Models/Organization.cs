﻿using System.ComponentModel.DataAnnotations;

namespace Hrms_final_draft.Models
{
    public class Organization
    {
        [Key]
        public int OrganizationId { get; set; }

        [Required]
        public string OrganizationName { get; set; }

        public string OrganizationDescription { get; set; }

        public string OrganizationAddress { get; set; }

        public string OrganizationPhone { get; set; }

        public string OrganizationEmail { get; set; }

        public string OrganizationLogo { get; set; }
    }
}
