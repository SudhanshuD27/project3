﻿namespace Hrms_final_draft.Models
{
    public class Resign
    {
        public int Id { get; set; }
        public string? employeeName { get; set; }
        public string? employeeEmail { get; set; }
        public string? departmentHead { get; set; }
        public string? resignationDate { get; set; }
        public string? lastDay { get; set; }
    }
}
