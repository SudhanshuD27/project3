﻿
using Hrms_final_draft.Models;
using Microsoft.EntityFrameworkCore;


namespace Hrms_final_draft.Data
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> User { get; set; }
        public DbSet<Organization> Organization { get; set; }
        public DbSet<AdminDocuments> AdminDocuments { get; set; }



    }
}
